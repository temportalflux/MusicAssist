## MusicAssist

* **Author**: (Put author’s name here, including Discord username. If they accept contributions in code or donations, note this here as well.)
* **Version**: (Note current version of module here.)
* **Foundry VTT Compatibility**: (Note which versions of Foundry Virtual Tabletop the module is compatible with.)
* **System Compatibility (If applicable)**: (Note which systems of Foundry Virtual Tabletop the module is compatible with.)
* **Module Requirement(s)**: (If the module requires other modules to function, note them here.)
* **Module Conflicts**: (If the module conflicts with other modules, either partially or completely, note conflicts here.)
* **Translation Support**: (Note which languages are supported, and if they have (full) or (partial) translations.

### Link(s) to Module
* https://github.com/temportalflux/MusicAssist
* https://raw.githubusercontent.com/temportalflux/MusicAssist/master/module.json

### Description
A module for FoundryVTT which adds support for youtube tracks in audio playlists
(Describe the module here. This should include the module’s function, installation instructions, and anything important to note. Due to the particular oddities of some archiving programs (WinRar, 7zip), and GitHub zip folders, including a screenshot of what the module should look like file-wise in the “public/modules/examplemodule” is appreciated, though not required.)

---